<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'kmGaeDPsmaYjQzZFmQwH2aule');
    define('CONSUMER_SECRET', 'coSD0mghdXLAR5Kgu6mHWI6MdfiODQ0JXWemAqU00yCtp2QhlA');

    // User Access Token
    define('ACCESS_TOKEN', '79699534-k2Wr4DhkFdnLgnTYX6HpNFw0kaSc0JaCT4ilvEpWg');
    define('ACCESS_SECRET', 'hm8DIHLjIhm0fc1edxMgPfSA6LbZ5ZehDZW5ud3OaPxBw');
	
	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));